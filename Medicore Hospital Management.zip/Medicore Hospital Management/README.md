# 🏥 MediCore — Hospital Management System

A full-stack-style, single-file Hospital Management System built with vanilla HTML, CSS, and JavaScript. Designed as a functional demo/prototype with role-based dashboards for Patients, Doctors, and Administrators.

---

## 📸 Preview

> Open `medicore-hms.html` directly in your browser — no build step, no server needed.

---

## ✨ Features

### 🔐 Authentication
- Role-based login: **Patient**, **Doctor**, **Admin**
- Registration with role-specific fields
- Demo credential quick-fill buttons
- Password show/hide toggle

### 👤 Patient Dashboard
- Book appointments by browsing doctors and selecting time slots
- View upcoming and past appointments
- Cancel confirmed appointments
- Access billing history and consultation fees
- Manage personal profile

### 🩺 Doctor Dashboard
- View all scheduled appointments
- Update appointment status (confirm, complete, cancel)
- Patient overview and consultation details
- Manage doctor profile (specialization, fees, availability)

### 🛡️ Admin Dashboard
- Overview stats: total patients, doctors, appointments, revenue
- Manage all doctors and patients
- System-wide appointment management
- Full billing records with payment status
- Admin profile management

---

## 🚀 Getting Started

### Prerequisites

- A modern web browser (Chrome, Firefox, Edge, Safari)
- [VS Code](https://code.visualstudio.com/) *(recommended)*
- [Live Server extension](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) *(optional, for live reload)*

### Running Locally

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/medicore-hms.git
   cd medicore-hms
   ```

2. **Open in VS Code**
   ```bash
   code .
   ```

3. **Launch the app**

   **Option A — Direct open:**
   Simply double-click `medicore-hms.html` to open in your browser.

   **Option B — Live Server (recommended):**
   - Install the [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) extension in VS Code
   - Right-click `medicore-hms.html` → **Open with Live Server**
   - App opens at `http://127.0.0.1:5500/medicore-hms.html`

---

## 🧪 Demo Credentials

Use the quick-fill buttons on the login screen, or enter manually:

| Role    | Email                   | Password   |
|---------|-------------------------|------------|
| Admin   | admin@medicore.com      | admin123   |
| Doctor  | dr.smith@medicore.com   | doctor123  |
| Patient | patient@medicore.com    | patient123 |

---

## 🗂️ Project Structure

```
medicore-hms/
├── medicore-hms.html     # Entire application (HTML + CSS + JS)
└── README.md             # Project documentation
```

> This is a single-file application — all styles and logic are self-contained within the HTML file.

---

## 🛠️ Tech Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Markup     | HTML5                             |
| Styling    | CSS3 (Custom Properties, Flexbox, Grid) |
| Logic      | Vanilla JavaScript (ES6+)         |
| Fonts      | Google Fonts — DM Sans, DM Serif Display |
| Icons      | Unicode Emoji                     |
| AI Assist  | Microsoft Copilot                 |

---

## 📋 Functional Highlights

- **In-memory data store** — all appointments, users, and billing persist during the session
- **Dynamic rendering** — dashboards render content based on logged-in role
- **Toast notifications** — user feedback on all key actions
- **Responsive layout** — sidebar + main content layout with clean card components
- **Form validation** — inline error messages on login and registration

---

## 🔮 Future Improvements

- [ ] Backend integration (Node.js / Express or Firebase)
- [ ] Persistent storage with a database (MongoDB / PostgreSQL)
- [ ] Real authentication with JWT / OAuth
- [ ] SMS / email appointment reminders
- [ ] Doctor availability calendar
- [ ] Export reports as PDF
- [ ] Mobile-responsive sidebar (hamburger menu)

---

## 📄 License

This project is open-source and available under the [MIT License](LICENSE).

---

## 🙌 Acknowledgements

- Built with AI assistance using **Microsoft Copilot**
- Fonts by [Google Fonts](https://fonts.google.com/)
- Inspired by modern healthcare UI/UX patterns